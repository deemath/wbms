<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class works extends Controller
{
    public function works1(){
        return view('works');
    }
}
