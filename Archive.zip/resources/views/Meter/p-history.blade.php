<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment History</title>
        <link rel="stylesheet" href="{{asset('CSS/mobile.css')}}">
    </head>

    <body>

        <input type="search" style="width: 220px; height: 30px;">Search

        
        <div class="cus">
        <p>D.I.Jayasinghe</p>
        <p>38,Gampaha,Sri Lanka</p>
        <p>25784215932</p>
        <p>0786768882</p>
        </div>

        <br>

        <div class="Detail">
            <div>
                <p>Month</p>
                <p>Account No</p>
                <p>No of Units</p>
                <p>Billed-Amount</p>
                <p>Paid-Amount</p>
                <p>Balance</p>
            </div>

            <div>
                <p> : January</p>
                <p> : 25784215932</p>
                <p> : 52</p>
                <p> : 2470.00</p>
                <p> : 2470.00</p>
                <p > : 0.00</p>
            </div>
        </div>

        <div class="Detail">
            <div>
                <p>Month</p>
                <p>Account No</p>
                <p>No of Units</p>
                <p>Billed-Amount</p>
                <p>Paid-Amount</p>
                <p>Balance</p>
            </div>

            <div>
                <p> : February</p>
                <p> : 25784215932</p>
                <p> : 52</p>
                <p> : 2470.00</p>
                <p> : 2450.00</p>
                <p style="color: red; font-weight: bold;"> : -20.00</p>
            </div>
        </div>

        <div class="Detail">
            <div>
                <p>Month</p>
                <p>Account No</p>
                <p>No of Units</p>
                <p>Billed-Amount</p>
                <p>Paid-Amount</p>
                <p>Balance</p>
            </div>

            <div>
                <p> : March</p>
                <p> : 25784215932</p>
                <p> : 52</p>
                <p> : 2450.00</p>
                <p> : 2470.00</p>
                <p style="color: green; font-weight: bold;"> : +20.00</p>
            </div>
        </div>

        <div class="Detail">
            <div>
                <p>Month</p>
                <p>Account No</p>
                <p>No of Units</p>
                <p>Billed-Amount</p>
                <p>Paid-Amount</p>
                <p>Balance</p>
            </div>

            <div>
                <p> : April</p>
                <p> : 25784215932</p>
                <p> : 54</p>
                <p> : 3000.00</p>
                <p> : 3000.00</p>
                <p> : 0.00</p>
            </div>
        </div>
    </body>

</html>